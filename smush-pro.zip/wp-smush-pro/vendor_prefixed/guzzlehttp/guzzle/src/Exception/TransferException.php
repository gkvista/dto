<?php

namespace Smush_Vendor\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}