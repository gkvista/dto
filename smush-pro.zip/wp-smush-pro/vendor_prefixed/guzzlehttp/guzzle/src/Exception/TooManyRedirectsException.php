<?php

namespace Smush_Vendor\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}