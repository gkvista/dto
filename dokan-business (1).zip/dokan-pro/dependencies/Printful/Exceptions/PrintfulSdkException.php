<?php

namespace WeDevs\DokanPro\Dependencies\Printful\Exceptions;

/**
 * WeDevs\DokanPro\Dependencies\Printful SDK exception
 */
class PrintfulSdkException extends PrintfulException
{
}