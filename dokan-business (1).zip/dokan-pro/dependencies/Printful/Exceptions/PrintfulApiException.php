<?php

namespace WeDevs\DokanPro\Dependencies\Printful\Exceptions;

/**
 * WeDevs\DokanPro\Dependencies\Printful exception returned from the API
 */
class PrintfulApiException extends PrintfulException
{
}