<?php

namespace WeDevs\DokanPro\Dependencies\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
