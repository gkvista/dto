<?php

namespace WeDevs\DokanPro\Dependencies\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
