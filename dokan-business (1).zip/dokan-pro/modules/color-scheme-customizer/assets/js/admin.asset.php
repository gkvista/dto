<?php return array('dependencies' => array(), 'version' => '0da4362e3f97d545c14a');
