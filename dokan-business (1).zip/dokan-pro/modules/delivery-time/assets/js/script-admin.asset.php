<?php return array('dependencies' => array(), 'version' => '97a19e5ff5a4fe5688e3');
