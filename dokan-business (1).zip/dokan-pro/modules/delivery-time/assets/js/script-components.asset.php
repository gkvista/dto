<?php return array('dependencies' => array('jquery'), 'version' => '48ee6ea2cbac4ecc2839');
