<?php return array('dependencies' => array(), 'version' => '012c1771aee8cf5942fa');
