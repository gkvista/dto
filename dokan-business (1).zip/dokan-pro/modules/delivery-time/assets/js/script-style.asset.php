<?php return array('dependencies' => array(), 'version' => '1103f878086ef250e18f');
