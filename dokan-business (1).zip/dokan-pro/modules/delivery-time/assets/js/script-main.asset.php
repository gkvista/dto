<?php return array('dependencies' => array(), 'version' => '2dfbe198a042818f3453');
