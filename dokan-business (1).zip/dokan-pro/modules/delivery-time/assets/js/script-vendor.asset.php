<?php return array('dependencies' => array(), 'version' => '7c7f276b50f8d0c157ac');
