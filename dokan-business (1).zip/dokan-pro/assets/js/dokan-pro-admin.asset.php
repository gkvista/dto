<?php return array('dependencies' => array(), 'version' => 'e85d9f646991922c5ad7');
