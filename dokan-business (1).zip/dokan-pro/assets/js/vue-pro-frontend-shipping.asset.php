<?php return array('dependencies' => array(), 'version' => '21e1bf4a197062638c8e');
