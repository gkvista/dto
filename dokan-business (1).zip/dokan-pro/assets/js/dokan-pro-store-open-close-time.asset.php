<?php return array('dependencies' => array(), 'version' => '5321db8a1d53db3dfbbf');
