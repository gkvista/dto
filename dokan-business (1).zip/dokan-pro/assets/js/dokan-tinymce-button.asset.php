<?php return array('dependencies' => array(), 'version' => '6404138dbb2fe21c2bcc');
