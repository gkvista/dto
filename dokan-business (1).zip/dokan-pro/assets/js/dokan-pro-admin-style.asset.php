<?php return array('dependencies' => array(), 'version' => 'a4eb077f82dd40b75023');
