<?php return array('dependencies' => array(), 'version' => '38f7b4e4702df28b4920');
