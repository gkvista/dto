<?php return array('dependencies' => array(), 'version' => 'dc583dc199fb6dd9f3e0');
