<?php return array('dependencies' => array('jquery'), 'version' => 'fe7ba370345d236f073a');
