<?php return array('dependencies' => array(), 'version' => '57baec29e716d4b1ac4f');
