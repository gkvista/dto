<?php return array('dependencies' => array(), 'version' => '960462491f5f93d465db');
