<?php return array('dependencies' => array(), 'version' => '429a323a9c61b162d73e');
